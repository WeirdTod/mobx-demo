import React from "react";

class Parent extends React.Component{
    propParent="props from parent"
    render() {
        return (
            <div></div>
        );
    }
}

class DemoTest extends Parent{
    constructor(props) {
        super(props);
        console.log(this.propParent);
    }
    render() {
        const mapper = {
            a: () => <div></div>,
            b: () => <span></span>
        };
        const com = () => <div />;
        const Com = () => <div />;
        return (
            <div>
                <mapper.a />
                <com>dddd</com>
                <Com>dddd2</Com>
            </div>
        );
    }
}

export { DemoTest };