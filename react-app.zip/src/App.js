import logo from './logo.svg';
import './App.css';
import { DemoState } from "./DemoState";
import { DemoClassFunc } from "./DemoClassFunc";
import { DemoClassFunc2 } from "./DemoClassFunc2";
import { DemoTest } from "./DemoTest";

function App() {
  return (
    <div className="App">
      <h1>React</h1>
      <DemoState />
      {/* <DemoClassFunc /> */}
      {/* <DemoClassFunc2 /> */}
      <DemoTest />
    </div>
  );
}

export default App;
